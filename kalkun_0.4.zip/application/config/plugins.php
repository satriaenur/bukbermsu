<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Plugins Directory
|--------------------------------------------------------------------------
|
| Set plugin directory, DO NOT CHANGE!
|
*/

$config['plugins_dir'] = APPPATH . "plugins/";

/* End of file plugins.php */
/* Location: ./application/config/plugins.php */