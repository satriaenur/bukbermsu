<h2>Welcome to Kalkun installation</h2>
<p>Hi and welcome to the installation of Kalkun, the open source web based SMS management/PHP Frontend for gammu-smsd. 
Before going to installation, have a look on these instruction to guide you to install.
Here is the installation step.
</p>

<p>
<ol>
<li>This welcome screen</li>
<li>Requirement check</li>
<li>Setup database connection</li>
<li>The installation result</li>
</ol>
</p>

<p>So? Should we start now?</p>
<p>&nbsp;</p>

<div><a href="<?php echo site_url();?>/install/requirement_check" class="button">Start installation</a></div>
