#!/bin/sh

# Configure this (use absolute path)
PHP=/usr/bin/php # php cli path
DAEMON=/path/to/kalkun/scripts/daemon.php # daemon.php path

# Execute
$PHP $DAEMON