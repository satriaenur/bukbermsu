#!/bin/sh

PHP=/usr/bin/php # php cli path
TRANSLATOR=/path/to/translator.php # translator.php path

# execute it and pass all argument
$PHP $TRANSLATOR $@
